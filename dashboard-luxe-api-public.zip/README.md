# 📦 Dashboard Luxe API – Scraper Vestiaire Collective

Cette API Python utilise Flask pour scraper dynamiquement des produits sur Vestiaire Collective selon une marque + mot-clé.

## ✅ Fonctionnalités

- Scraping en temps réel de 10 résultats maximum
- Paramètres dynamiques via URL :
  - `motcle` : nom du produit (ex : speedy 30)
  - `marque` : nom de la marque (ex : louis vuitton)

## 🔧 Exemple d'utilisation

```
GET https://dashboard-luxe-api.onrender.com/search?motcle=speedy&marque=louis+vuitton
```

## 📁 Fichiers

- `app.py` : Serveur principal
- `requirements.txt` : Dépendances
- `render.yaml` : Configuration Render.com

## 🚀 Déploiement sur Render

### Étapes :

1. Va sur [https://github.com/new](https://github.com/new) et crée un dépôt `dashboard-luxe-api`.
2. Uploade ces 3 fichiers : `app.py`, `requirements.txt`, `render.yaml`.
3. Va sur [https://render.com](https://render.com) et connecte ton GitHub.
4. Clique sur **"New Web Service"**.
5. Sélectionne le dépôt `dashboard-luxe-api`.
6. Laisse Render déployer automatiquement.

⚠️ Ne change pas le `Start Command`, Render lira `render.yaml`.

---

## 📦 API Endpoint

| Paramètre | Description          | Exemple               |
|-----------|----------------------|------------------------|
| motcle    | Nom du produit       | speedy                |
| marque    | Marque du produit    | louis+vuitton         |

---

## ✨ Exemples de requêtes

```bash
https://votre-api.onrender.com/search?motcle=backpack&marque=gucci
https://votre-api.onrender.com/search?motcle=flap&marque=chanel
```

---

## 🙌 Crée par Selezione Luxe & OpenAI