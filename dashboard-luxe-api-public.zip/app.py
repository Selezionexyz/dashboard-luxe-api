
from flask import Flask, request, jsonify
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)

@app.route('/search')
def search_vestiaire():
    query = request.args.get('motcle', '')
    brand = request.args.get('marque', '')
    url = f'https://www.vestiairecollective.com/search/?q={brand}+{query}'

    headers = {
        "User-Agent": "Mozilla/5.0"
    }
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        return jsonify({"error": "Failed to fetch data"}), 500

    soup = BeautifulSoup(response.text, 'html.parser')
    results = []

    for item in soup.select('a[itemprop="url"]')[:10]:
        title = item.get('title') or item.text.strip()
        link = "https://www.vestiairecollective.com" + item.get('href')
        results.append({
            "title": title,
            "link": link
        })

    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True)
